import random, string
import webbrowser
import time
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
import requests
import sys,time,os
from colorama import init
init()
os.system('cls')
os.system('cls')
print("""\033[1;31;40m
 ███▄    █  ██▓▄▄▄█████▓ ██▀███   ▒█████      ███▄ ▄███▓ ██▓ ███▄    █ ▓█████  ██▀███  
 ██ ▀█   █ ▓██▒▓  ██▒ ▓▒▓██ ▒ ██▒▒██▒  ██▒   ▓██▒▀█▀ ██▒▓██▒ ██ ▀█   █ ▓█   ▀ ▓██ ▒ ██▒
▓██  ▀█ ██▒▒██▒▒ ▓██░ ▒░▓██ ░▄█ ▒▒██░  ██▒   ▓██    ▓██░▒██▒▓██  ▀█ ██▒▒███   ▓██ ░▄█ ▒
▓██▒  ▐▌██▒░██░░ ▓██▓ ░ ▒██▀▀█▄  ▒██   ██░   ▒██    ▒██ ░██░▓██▒  ▐▌██▒▒▓█  ▄ ▒██▀▀█▄  
▒██░   ▓██░░██░  ▒██▒ ░ ░██▓ ▒██▒░ ████▓▒░   ▒██▒   ░██▒░██░▒██░   ▓██░░▒████▒░██▓ ▒██▒
░ ▒░   ▒ ▒ ░▓    ▒ ░░   ░ ▒▓ ░▒▓░░ ▒░▒░▒░    ░ ▒░   ░  ░░▓  ░ ▒░   ▒ ▒ ░░ ▒░ ░░ ▒▓ ░▒▓░
░ ░░   ░ ▒░ ▒ ░    ░      ░▒ ░ ▒░  ░ ▒ ▒░    ░  ░      ░ ▒ ░░ ░░   ░ ▒░ ░ ░  ░  ░▒ ░ ▒░
   ░   ░ ░  ▒ ░  ░        ░░   ░ ░ ░ ░ ▒     ░      ░    ▒ ░   ░   ░ ░    ░     ░░   ░ 
         ░  ░              ░         ░ ░            ░    ░           ░    ░  ░   ░     
                                                                                       """)
                                                                  

print("\n\033[1;33;40m╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╮\n")
num=input('Input How Many Codes You want to mine: ')

f=open("Nitro Codes.txt","w", encoding='utf-8')

print("\n\033[1;34;40m╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╮\n")
      
for n in range(int(num)):
   y = ''.join(random.choice(string.ascii_uppercase + string.digits + string.ascii_lowercase) for _ in range(16))
   f.write('https://discord.gift/')
   f.write(y)
   f.write("\n")

f.close()
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO

#=============Checker=========================
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO

with open("Nitro Codes.txt") as f:
    for line in f:
        nitro = line.strip("\n")

        url = "https://discordapp.com/api/v6/entitlements/gift-codes/" + nitro + "?with_application=false&with_subscription_plan=true"

        r = requests.get(url)

        if r.status_code == 200:
            print(" Valid | {} ".format(line.strip("\n")))
            break
        else:
        	print(" \033[1;31;40mInvalid | {} ".format(line.strip("\n")))
print("\n\033[1;34;40m╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯\033[1;34;40m")
input("Press Enter to close the program")
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO
#DONT SKID PLEASE THIS IS DEVELOPED BY DANKO